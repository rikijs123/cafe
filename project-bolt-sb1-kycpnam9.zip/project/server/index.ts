import express, { Express } from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import { initializeDatabase } from './database.js';
import { createDefaultUser } from './routes/auth.js';
import publicRoutes from './routes/public.js';
import authRoutes from './routes/auth.js';
import adminMenuRoutes from './routes/admin/menu.js';
import adminTestimonialRoutes from './routes/admin/testimonials.js';
import adminHoursRoutes from './routes/admin/hours.js';
import adminContactRoutes from './routes/admin/contact.js';
import adminGalleryRoutes from './routes/admin/gallery.js';
import adminSettingsRoutes from './routes/admin/settings.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3001;
const NODE_ENV = process.env.NODE_ENV || 'development';

const app: Express = express();

// Initialize database
initializeDatabase();

// Security middleware
app.use(helmet());

// CORS configuration
const allowedOrigins = ['http://localhost:5173'];
if (NODE_ENV === 'production') {
  allowedOrigins.push(process.env.PRODUCTION_DOMAIN || 'http://localhost:5173');
}

app.use(
  cors({
    origin: allowedOrigins,
    credentials: true,
  })
);

// Body parsing
app.use(express.json());

// Rate limiting for auth
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  message: 'Too many login attempts, please try again later',
});

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

// Public routes
app.use('/api', publicRoutes);

// Auth routes (login has rate limiting)
app.post('/api/auth/login', loginLimiter, authRoutes);
app.use('/api/auth', authRoutes);

// Admin routes
app.use('/api/admin/menu', adminMenuRoutes);
app.use('/api/admin/testimonials', adminTestimonialRoutes);
app.use('/api/admin/hours', adminHoursRoutes);
app.use('/api/admin/contact', adminContactRoutes);
app.use('/api/admin/gallery', adminGalleryRoutes);
app.use('/api/admin/settings', adminSettingsRoutes);

// Serve frontend in production
if (NODE_ENV === 'production') {
  const clientDist = path.join(__dirname, '../client/dist');
  app.use(express.static(clientDist));
  app.get('*', (req, res) => {
    res.sendFile(path.join(clientDist, 'index.html'));
  });
}

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  console.log(`Environment: ${NODE_ENV}`);

  // Create default admin user if needed
  createDefaultUser();
});
