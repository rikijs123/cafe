import Database from 'better-sqlite3';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dbPath = path.join(__dirname, '../database.sqlite');

const db = new Database(dbPath);
db.pragma('journal_mode = WAL');

export function initializeDatabase() {
  // Create tables if they don't exist
  db.exec(`
    CREATE TABLE IF NOT EXISTS menu_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name_lv TEXT NOT NULL,
      name_en TEXT NOT NULL,
      name_ru TEXT NOT NULL,
      description_lv TEXT,
      description_en TEXT,
      description_ru TEXT,
      price REAL NOT NULL,
      category TEXT NOT NULL CHECK(category IN ('breakfast', 'coffee', 'dessert', 'lunch')),
      active INTEGER DEFAULT 1,
      sort_order INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS testimonials (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      text_lv TEXT NOT NULL,
      text_en TEXT NOT NULL,
      text_ru TEXT NOT NULL,
      rating INTEGER NOT NULL CHECK(rating >= 1 AND rating <= 5),
      active INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS contact_info (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      phone TEXT NOT NULL,
      email TEXT NOT NULL,
      address_lv TEXT NOT NULL,
      address_en TEXT NOT NULL,
      address_ru TEXT NOT NULL,
      instagram TEXT,
      facebook TEXT,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS working_hours (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      day_lv TEXT NOT NULL,
      day_en TEXT NOT NULL,
      day_ru TEXT NOT NULL,
      hours TEXT NOT NULL,
      day_num INTEGER UNIQUE
    );

    CREATE TABLE IF NOT EXISTS gallery_images (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      url TEXT NOT NULL,
      caption_lv TEXT,
      caption_en TEXT,
      caption_ru TEXT,
      source_name TEXT,
      source_author TEXT,
      source_url TEXT,
      license_type TEXT,
      sort_order INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      password_changes_left INTEGER DEFAULT 2,
      reset_token TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // Check if data already exists
  const menuCount = db.prepare('SELECT COUNT(*) as count FROM menu_items').get() as { count: number };

  if (menuCount.count === 0) {
    seedDatabase();
  }
}

function seedDatabase() {
  // Menu items
  const insertMenuItem = db.prepare(`
    INSERT INTO menu_items (name_lv, name_en, name_ru, description_lv, description_en, description_ru, price, category, sort_order)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  insertMenuItem.run(
    'Brokastu plate',
    'Breakfast Platter',
    'Завтрак',
    'Maizīte, desa, ola, siers, tomāti',
    'Toast, sausage, egg, cheese, tomato',
    'Тосты, колбаса, яйцо, сыр, помидоры',
    12.00,
    'breakfast',
    1
  );

  insertMenuItem.run(
    'Avokado grauzdiņi',
    'Avocado Toast',
    'Авокадо на хлебе',
    'Maizīte ar avokado, vistas gaļu un olu',
    'Toasted bread with avocado, chicken and egg',
    'Хлеб с авокадо, курица и яйцо',
    9.50,
    'breakfast',
    2
  );

  insertMenuItem.run(
    'Biezpiena sieriņi',
    'Cottage Cheese Pancakes',
    'Сырники',
    'Sauļi ar skābiem krējumiem un ievāru',
    'Served with sour cream and jam',
    'Подается со сметаной и вареньем',
    7.00,
    'breakfast',
    3
  );

  insertMenuItem.run(
    'Cappuccino',
    'Cappuccino',
    'Капучино',
    'Klasisks kafijas dzēriens ar putām',
    'Classic espresso with steamed milk foam',
    'Классический эспрессо с молочной пеной',
    3.50,
    'coffee',
    1
  );

  insertMenuItem.run(
    'Karstā šokolāde',
    'Hot Chocolate',
    'Горячий шоколад',
    'Karstā šokolāde ar krējuma putām',
    'Hot chocolate with whipped cream',
    'Горячий шоколад со взбитыми сливками',
    4.00,
    'coffee',
    2
  );

  insertMenuItem.run(
    'Medus kūka',
    'Honey Cake',
    'Медовый пирог',
    'Mājīgi cepta medus kūka ar mandelēm',
    'Homemade honey cake with almonds',
    'Домашний медовый пирог с миндалем',
    5.50,
    'dessert',
    1
  );

  insertMenuItem.run(
    'Tiramisu',
    'Tiramisu',
    'Тирамису',
    'Tradicionālais itāļu deseris',
    'Traditional Italian dessert',
    'Традиционный итальянский десерт',
    6.00,
    'dessert',
    2
  );

  // Testimonials
  const insertTestimonial = db.prepare(`
    INSERT INTO testimonials (name, text_lv, text_en, text_ru, rating)
    VALUES (?, ?, ?, ?, ?)
  `);

  insertTestimonial.run(
    'Anita Ozoliņa',
    'Visvairāk piepatīk mājīgā atmosfēra un svaigi cepumi! Pēkšņi jūtos kā mājās.',
    'I love the cozy atmosphere and fresh pastries! I suddenly feel at home.',
    'Мне нравится уютная атмосфера и свежие пирожные! Я вдруг чувствую себя дома.',
    5
  );

  insertTestimonial.run(
    'Jānis Bērzs',
    'Labākais kafijas dzēriens pilsētā! Barista zina savu darbu.',
    'The best coffee drink in town! The barista knows their craft.',
    'Лучший кофе в городе! Бариста знает свое дело.',
    5
  );

  insertTestimonial.run(
    'Ieva Kalniņa',
    'Ģimenes kafejnīca ar lielu sirdi. Visas kūkas ir pagatavots ar mīlestību.',
    'A family cafe with a big heart. All cakes are made with love.',
    'Семейное кафе с большим сердцем. Все торты сделаны с любовью.',
    5
  );

  // Contact info
  const insertContact = db.prepare(`
    INSERT INTO contact_info (phone, email, address_lv, address_en, address_ru, instagram, facebook)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);

  insertContact.run(
    '+371 20 123 456',
    'info@kafejnica.lv',
    'Raiņa iela 5, Jelgava, LV-3001',
    'Raiņa Street 5, Jelgava, LV-3001',
    'Улица Райна 5, Елгава, LV-3001',
    'https://instagram.com/kafejnica',
    'https://facebook.com/kafejnica'
  );

  // Working hours
  const insertHours = db.prepare(`
    INSERT INTO working_hours (day_lv, day_en, day_ru, hours, day_num)
    VALUES (?, ?, ?, ?, ?)
  `);

  insertHours.run('Pirmdiena', 'Monday', 'Понедельник', '8:00–20:00', 0);
  insertHours.run('Otrdiena', 'Tuesday', 'Вторник', '8:00–20:00', 1);
  insertHours.run('Trešdiena', 'Wednesday', 'Среда', '8:00–20:00', 2);
  insertHours.run('Ceturtdiena', 'Thursday', 'Четверг', '8:00–20:00', 3);
  insertHours.run('Piektdiena', 'Friday', 'Пятница', '8:00–20:00', 4);
  insertHours.run('Sestdiena', 'Saturday', 'Суббота', '9:00–21:00', 5);
  insertHours.run('Svētdiena', 'Sunday', 'Воскресенье', '9:00–18:00', 6);

  // Gallery images (using Pexels URLs)
  const insertGallery = db.prepare(`
    INSERT INTO gallery_images (url, caption_lv, caption_en, caption_ru, source_name, source_author, source_url, license_type, sort_order)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  insertGallery.run(
    'https://images.pexels.com/photos/312418/pexels-photo-312418.jpeg',
    'Mūsu kafejnīca',
    'Our cafe interior',
    'Наша кафе',
    'Pexels',
    'Pixabay',
    'https://www.pexels.com/photo/coffee-3/',
    'Free to use',
    1
  );

  insertGallery.run(
    'https://images.pexels.com/photos/312418/pexels-photo-312418.jpeg',
    'Kafijas uzgale',
    'Coffee presentation',
    'Подача кофе',
    'Pexels',
    'Pixabay',
    'https://www.pexels.com/',
    'Free to use',
    2
  );

  insertGallery.run(
    'https://images.pexels.com/photos/312418/pexels-photo-312418.jpeg',
    'Kūku šēfpavārs',
    'Our pastry chef',
    'Наш кондитер',
    'Pexels',
    'Pixabay',
    'https://www.pexels.com/',
    'Free to use',
    3
  );
}

export default db;
