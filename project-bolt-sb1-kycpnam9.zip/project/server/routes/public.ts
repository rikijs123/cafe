import { Router, Response } from 'express';
import db from '../database.js';

const router = Router();

// GET /api/menu - Active menu items only
router.get('/menu', (req, res: Response) => {
  try {
    const items = db
      .prepare('SELECT * FROM menu_items WHERE active = 1 ORDER BY category, sort_order')
      .all();

    res.json(items);
  } catch (error) {
    console.error('Menu fetch error:', error);
    res.status(500).json({ error: 'Failed to fetch menu' });
  }
});

// GET /api/testimonials - Active testimonials only
router.get('/testimonials', (req, res: Response) => {
  try {
    const testimonials = db.prepare('SELECT * FROM testimonials WHERE active = 1').all();

    res.json(testimonials);
  } catch (error) {
    console.error('Testimonials fetch error:', error);
    res.status(500).json({ error: 'Failed to fetch testimonials' });
  }
});

// GET /api/contact
router.get('/contact', (req, res: Response) => {
  try {
    const contact = db.prepare('SELECT * FROM contact_info LIMIT 1').get();

    res.json(contact || {});
  } catch (error) {
    console.error('Contact fetch error:', error);
    res.status(500).json({ error: 'Failed to fetch contact' });
  }
});

// GET /api/hours
router.get('/hours', (req, res: Response) => {
  try {
    const hours = db.prepare('SELECT * FROM working_hours ORDER BY day_num').all();

    res.json(hours);
  } catch (error) {
    console.error('Hours fetch error:', error);
    res.status(500).json({ error: 'Failed to fetch hours' });
  }
});

// GET /api/gallery
router.get('/gallery', (req, res: Response) => {
  try {
    const images = db.prepare('SELECT * FROM gallery_images ORDER BY sort_order').all();

    res.json(images);
  } catch (error) {
    console.error('Gallery fetch error:', error);
    res.status(500).json({ error: 'Failed to fetch gallery' });
  }
});

export default router;
