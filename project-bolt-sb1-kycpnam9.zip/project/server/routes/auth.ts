import { Router, Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import db from '../database.js';
import { generateToken } from '../middleware/auth.js';

const router = Router();

// Generate random password
function generateRandomPassword(length: number = 8): string {
  return crypto.randomBytes(length).toString('hex').slice(0, length);
}

// Create default admin user on startup if no users exist
export function createDefaultUser() {
  try {
    const userCount = db.prepare('SELECT COUNT(*) as count FROM users').get() as { count: number };

    if (userCount.count === 0) {
      const password = generateRandomPassword(8);
      const passwordHash = bcrypt.hashSync(password, 10);

      db.prepare(`
        INSERT INTO users (username, password_hash, password_changes_left)
        VALUES (?, ?, ?)
      `).run('admin', passwordHash, 2);

      console.log('\n========================================');
      console.log('DEFAULT ADMIN USER CREATED');
      console.log('========================================');
      console.log(`Username: admin`);
      console.log(`Password: ${password}`);
      console.log('========================================\n');
    }
  } catch (error) {
    console.error('Error creating default user:', error);
  }
}

// Sanitize HTML from input
function sanitizeInput(text: string): string {
  return text.replace(/<[^>]*>/g, '');
}

// POST /api/auth/login
router.post('/login', (req: Request, res: Response) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password required' });
    }

    const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username) as any;

    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const passwordValid = bcrypt.compareSync(password, user.password_hash);

    if (!passwordValid) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = generateToken(user.id);

    res.json({ token, userId: user.id });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Login failed' });
  }
});

// POST /api/auth/forgot-password
router.post('/forgot-password', (req: Request, res: Response) => {
  try {
    const { username } = req.body;

    if (!username) {
      return res.status(400).json({ error: 'Username required' });
    }

    const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username) as any;

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const resetToken = crypto.randomBytes(32).toString('hex');

    db.prepare('UPDATE users SET reset_token = ? WHERE id = ?').run(resetToken, user.id);

    console.log(`\nPassword reset token for ${username}: ${resetToken}\n`);

    res.json({
      message: 'Reset token generated',
      resetToken: resetToken,
      note: 'In production, this would be sent via email',
    });
  } catch (error) {
    console.error('Forgot password error:', error);
    res.status(500).json({ error: 'Request failed' });
  }
});

// POST /api/auth/reset-password
router.post('/reset-password', (req: Request, res: Response) => {
  try {
    const { resetToken, newPassword, confirmPassword } = req.body;

    if (!resetToken || !newPassword || !confirmPassword) {
      return res.status(400).json({ error: 'Token and passwords required' });
    }

    if (newPassword !== confirmPassword) {
      return res.status(400).json({ error: 'Passwords do not match' });
    }

    const user = db.prepare('SELECT * FROM users WHERE reset_token = ?').get(resetToken) as any;

    if (!user) {
      return res.status(401).json({ error: 'Invalid reset token' });
    }

    const passwordHash = bcrypt.hashSync(newPassword, 10);

    db.prepare('UPDATE users SET password_hash = ?, reset_token = NULL WHERE id = ?').run(
      passwordHash,
      user.id
    );

    res.json({ message: 'Password reset successfully' });
  } catch (error) {
    console.error('Reset password error:', error);
    res.status(500).json({ error: 'Reset failed' });
  }
});

export default router;
