import { Router, Response } from 'express';
import db from '../../database.js';
import { verifyToken, AuthRequest } from '../../middleware/auth.js';

const router = Router();

function sanitizeInput(text: string): string {
  return text.replace(/<[^>]*>/g, '');
}

// GET /api/admin/menu - All items
router.get('/', verifyToken, (req: AuthRequest, res: Response) => {
  try {
    const items = db.prepare('SELECT * FROM menu_items ORDER BY category, sort_order').all();

    res.json(items);
  } catch (error) {
    console.error('Menu fetch error:', error);
    res.status(500).json({ error: 'Failed to fetch menu' });
  }
});

// POST /api/admin/menu - Create
router.post('/', verifyToken, (req: AuthRequest, res: Response) => {
  try {
    const { name_lv, name_en, name_ru, description_lv, description_en, description_ru, price, category, active } =
      req.body;

    if (!name_lv || !name_en || !name_ru || !price || !category) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const stmt = db.prepare(`
      INSERT INTO menu_items (name_lv, name_en, name_ru, description_lv, description_en, description_ru, price, category, active, sort_order)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const result = stmt.run(
      sanitizeInput(name_lv),
      sanitizeInput(name_en),
      sanitizeInput(name_ru),
      sanitizeInput(description_lv || ''),
      sanitizeInput(description_en || ''),
      sanitizeInput(description_ru || ''),
      parseFloat(price),
      category,
      active ? 1 : 0,
      0
    ) as any;

    res.json({ id: result.lastInsertRowid });
  } catch (error) {
    console.error('Menu create error:', error);
    res.status(500).json({ error: 'Failed to create menu item' });
  }
});

// PUT /api/admin/menu/:id - Update
router.put('/:id', verifyToken, (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { name_lv, name_en, name_ru, description_lv, description_en, description_ru, price, category, active, sort_order } =
      req.body;

    if (!name_lv || !name_en || !name_ru || !price || !category) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    db.prepare(`
      UPDATE menu_items
      SET name_lv = ?, name_en = ?, name_ru = ?, description_lv = ?, description_en = ?, description_ru = ?, price = ?, category = ?, active = ?, sort_order = ?
      WHERE id = ?
    `).run(
      sanitizeInput(name_lv),
      sanitizeInput(name_en),
      sanitizeInput(name_ru),
      sanitizeInput(description_lv || ''),
      sanitizeInput(description_en || ''),
      sanitizeInput(description_ru || ''),
      parseFloat(price),
      category,
      active ? 1 : 0,
      sort_order || 0,
      parseInt(id)
    );

    res.json({ success: true });
  } catch (error) {
    console.error('Menu update error:', error);
    res.status(500).json({ error: 'Failed to update menu item' });
  }
});

// DELETE /api/admin/menu/:id
router.delete('/:id', verifyToken, (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;

    db.prepare('DELETE FROM menu_items WHERE id = ?').run(parseInt(id));

    res.json({ success: true });
  } catch (error) {
    console.error('Menu delete error:', error);
    res.status(500).json({ error: 'Failed to delete menu item' });
  }
});

export default router;
